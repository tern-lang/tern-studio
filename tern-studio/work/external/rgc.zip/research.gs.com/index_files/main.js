/* global $ */

'use strict';

var goldmanResearch = goldmanResearch || {};

goldmanResearch.loginForm = function() {
    var $form, 
        $login, 
        $alert;

    function init() {
        $login = $('.js-login');
        $form = $login.find('.js-form');
        $alert = $('.js-alert');

        if ($form.hasClass('js-login-form')) {
            $form.on('submit', _validateLoginForm);
            $('.js-btn-email-login').on('click', _handleEmailSubmit);
            $('.js-btn-change-pword').on('click', _handlePwordSubmit);
        } else if ($form.hasClass('js-password-form')) {
            $form.on('submit', _validatePasswordChangeForm);
        } else if ($form.hasClass('js-email-form')) {
            $('.js-btn-email-login').on('click', _handleLoginSubmit);
            $form.on('submit', _validateEmailForm);
        }
    }

    function _setAlert(message) {
        $alert.text(message).addClass('login__alert--shown');
    }

    function _setInputError($field) {
        $field.addClass('login__input--error');
        $field.one('change', function() {
            $field.removeClass('login__input--error');
        });
    }

    function _removeAlert() {
        $alert.text('').removeClass('login__alert--shown');
    }

    function _validateLoginForm(event) {
        var $inputUsername = $('.js-username');
        var $inputPassword = $('.js-password');
        var fallThrough = $('#fallThrough').val() === 'true';
        var passwordChange = $('#passwordChange').val() === 'true';
        //If one of the fields is not valid display an error and prevent the form from being submit
        if(
            (!fallThrough && !passwordChange) && 
            ($inputUsername.val() === '' || $inputPassword.val() === '')
        ) {
            event.preventDefault();
            _setAlert('Please enter your username and password');
            if ($inputUsername.val() === '') {
                _setInputError($inputUsername);
            }
            if ($inputPassword.val() === '') {
                _setInputError($inputPassword);
            }
            return false;
        }

        //if the form is valid remove the alert message
        _removeAlert();
    }

    function _validatePasswordChangeForm(event) {
        var $inputPassword = $('.js-password');
        var $inputNewPassword = $('.js-new-password');
        var $inputNewPasswordConfirm = $('.js-confirm-new-password');

        var containsError = false;
        if ($inputPassword.val() === '') {
            _setAlert('Please enter your current password');
            _setInputError($inputPassword);
            containsError = true;
        } else if ($inputNewPassword.val() === '' || $inputNewPasswordConfirm.val() === '') {
            _setAlert('Please enter your new password');
            if ($inputNewPassword.val() === '') {
                _setInputError($inputNewPassword);
            }
            if ($inputNewPasswordConfirm.val() === '') {
                _setInputError($inputNewPasswordConfirm);
            }
            containsError = true;
        } else if ($inputNewPassword.val() !== $inputNewPasswordConfirm.val()) {
            _setAlert('Please ensure your passwords match');
            _setInputError($inputNewPassword);
            _setInputError($inputNewPasswordConfirm);
            containsError = true;
        } else if ($inputPassword.val() === $inputNewPassword.val()) {
            _setAlert('New password is the same as current password');
            _setInputError($inputPassword);
            _setInputError($inputNewPassword);
            _setInputError($inputNewPasswordConfirm);
            containsError = true;
        } else if ($inputNewPassword.val().length < 7) {
            _setAlert('Please ensure that new password is at least 7 characters long');
            _setInputError($inputNewPassword);
            containsError = true;
        } else if (!/\d/.test($inputNewPassword.val())) {
            _setAlert('Please ensure that new password contains a number');
            _setInputError($inputNewPassword);
            containsError = true;
        }
        if (containsError) {
            event.preventDefault();
            return false;
        }

        _removeAlert();
    }

    function _validateEmailForm(event) {
        var $inputEmail = $('.js-email');
        if ($inputEmail.val() === '') {
            event.preventDefault();
            _setAlert('Please enter your email');
            _setInputError($inputEmail);
            return false;
        }
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (!re.test($inputEmail.val())) {
            event.preventDefault();
            _setAlert('Please enter a valid email address');
            _setInputError($inputEmail);
            return false;
        }

        _removeAlert();
    }

    function _handleEmailSubmit() {
        $('#fallThrough').val('true');
        $form.submit();
    }

    function _handlePwordSubmit() {
        var $inputUsername = $('.js-username');
        if ($inputUsername.val() === '') {
            _setAlert('Please enter username before changing password');
            _setInputError($inputUsername);
            return false;
        }
        $('#passwordChange').val('true');
        $form.submit();
    }

    function _handleLoginSubmit() {
        $('#fallThrough').val('false');
        $form.submit();
    }

    return {
        init: init
    };
};

$(document).ready(function() {
    var loginForm = goldmanResearch.loginForm();
    loginForm.init();
});